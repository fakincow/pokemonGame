export const GAME_STATES = {
        newGame: 'Waiting to start new game',
        playerTurn: 'Player turn',
        opponentTurn: 'Opponent turn',
        gameOver: ' Game Over',
        waiting: 'please wait',
        double: 'Double Bonus Throw'
      }
      