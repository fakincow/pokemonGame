/* eslint-disable */
import GamePage from './GamePage';

export default {
  title: "GamePage",
};

export const Default = () => <GamePage />;

Default.story = {
  name: 'default',
};
